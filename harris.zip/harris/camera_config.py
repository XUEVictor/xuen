# -*- coding: utf-8 -*
import cv2
import numpy as np
import math

#  1280 * 720
left_camera_matrix = np.array([[ 7.806487336979418e+02,    -0.007367763502046,  6.367423465846696e+02],
                                [       0, 7.803087127920052e+02,  3.787725513868699e+02],
                                [       0,         0,    1.0000]])

left_distortion = np.array([[0.061088464878672,  -0.118038898049642 ,  -2.869392065011951e-05, -3.323515856312678e-04]])
 
right_camera_matrix = np.array([[  7.639931573261881e+02,    1.659722277429643,  5.891279867785437e+02],
                               [          0, 7.633412936891895e+02,  3.628491990414868e+02],
                               [          0,         0,    1.0000]])
 
right_distortion = np.array([[0.060340733529833,  -0.120638414868920,-1.162163053125099e-04, -7.972342236904348e-04]])
 
R = np.matrix([
    [ 0.878431192412410,    -0.005875463215907,   0.477832731328557],
    [-0.004195413382888,    0.999791053390104,    0.020006200730118],
    [-0.477850435495729,   -0.019578776598798,    0.878222997195722],
])

print(R)
 
T = np.array([-88.549525614314940,0.616184985712436,25.603107735187420]) # cam1與cam2平移關係向量
# T = np.array([-88.549525614314940,0.0,0.0]) # cam1與cam2平移關係向量
 
size = (1280, 720) # 圖片尺寸
 
# 立體修正
R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(left_camera_matrix, left_distortion,right_camera_matrix, right_distortion, size, R,T)


theta_x = math.asin(-R[1,2])
theta_y = math.atan2(R[0,2],R[2,2])
theta_z = math.atan2(R[1,0],R[1,1])

# print('theta_x',(theta_x / math.pi) * 180)
# print('theta_y',(theta_y / math.pi) * 180)
# print('theta_z',(theta_z / math.pi) * 180)


# print(Q)
# print('R1',R1)
# print('R2',R2)
# print('validPixROI1',validPixROI1)
# print('validPixROI2',validPixROI2)



# 計算修正map
left_map1, left_map2 = cv2.initUndistortRectifyMap(left_camera_matrix, left_distortion, R1, P1, size, cv2.CV_16SC2)
right_map1, right_map2 = cv2.initUndistortRectifyMap(right_camera_matrix, right_distortion, R2, P2, size, cv2.CV_16SC2)


# calculate world_coord parameter
fx_left = left_camera_matrix[0,0]
fy_left = left_camera_matrix[1,1]
fx_right = right_camera_matrix[0,0]
fy_right = right_camera_matrix[1,1]
L_Pri_pt = np.array([left_camera_matrix[0,2],left_camera_matrix[1,2]])
R_Pri_pt = np.array([right_camera_matrix[0,2],right_camera_matrix[1,2]])

camera_angle_degree = 14.20

baseLine = 95


# print('fx_left',fx_left)
# print('fy_left',fy_left)
# print('fx_right',fx_right)
# print('fy_right',fy_right)
# print('L_Pri_pt',L_Pri_pt)
# print('R_Pri_pt',R_Pri_pt)

# camera parameter
R_FOCUS = 105
L_FOCUS = 45

# cam_L to grip
front_offset = 55
rigjt_offset = 47