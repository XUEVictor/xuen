# -*- coding: utf-8 -*-

import cv2 as cv
import camera_config
import numpy as np
import math
class world_coord:
    # 建構式
    def __init__(self):
        self.camera_angle_rad = (camera_config.camera_angle_degree / 180) * math.pi
        pass
    

    def cal_w_XYZ(self,Pot_L,Pot_R):
        exceed_Right = False
        exceed_Left = False
        A_Lr = 0
        A_Rr = 0


        x_left = Pot_L[0] - camera_config.L_Pri_pt[0]
        x_right = Pot_R[0] - camera_config.R_Pri_pt[0]
        y_left = Pot_L[1] - camera_config.L_Pri_pt[1]
        y_right = Pot_R[1] - camera_config.R_Pri_pt[1]


        theta_L = math.atan2(abs(x_left),camera_config.fx_left)
        theta_R = math.atan2(abs(x_right),camera_config.fx_right)
        
        theta_d_L = self.rad2degree(theta_L)
        theta_d_R = self.rad2degree(theta_R)
        
        locate = self.Quadrant(x_left,x_right)
        if(locate == 1):
            A_Lr,A_Rr,exceed_Right = self.First_quadrant(theta_L,theta_R)
        elif(locate == 2):
            A_Lr,A_Rr,exceed_Left,exceed_Right = self.Second_quadrant(theta_L,theta_R)
        elif(locate == 3):
            A_Lr,A_Rr,exceed_Left = self.Third_quadrant(theta_L,theta_R)
        else:
            A_Lr,A_Rr = self.Fourth_quadrant(theta_L,theta_R)

        k = (1 / (pow(math.cos(A_Rr),2)) - 1)/((1 / (pow(math.cos(A_Lr),2)) - 1))        
        ptr2Right_dis = self.cal_ptr2Right_dis(exceed_Left,exceed_Right,k)

        X = self.Cal_w_X(exceed_Left,exceed_Right,ptr2Right_dis)
        Z = abs(X) * math.tan(A_Lr)


        len_AL = math.sqrt(pow(X,2) + pow(Z,2))
        len_AR = math.sqrt(pow(ptr2Right_dis,2) + pow(Z,2))

        Y = self.cal_w_Y(y_left,camera_config.fy_left,len_AL,theta_L)
        # _Y = self.cal_w_Y(y_right,camera_config.fy_right,len_AR)

        # print('X : ',X)
        # print('Y : ',Y)
        # # print('_Y : ',_Y)
        # print('Z : ',Z)

        return X , Y , Z
    
    def cal_w_Y(self,P_y,fy,len_A,theta):
        return len_A * math.cos(theta) *(P_y / fy)


    def Quadrant(self,x_left,x_right):
        if(x_left > 0 and x_right > 0):
            return 1
        elif(x_left < 0 and x_right > 0):
            return 2
        elif(x_left < 0 and x_right < 0):
            return 3
        elif(x_left > 0 and x_right < 0):
            return 4
    # Right of triangle(Two state)
    def First_quadrant(self,theta_L,theta_R):
        exceed_Right = False
        A_Lr = (math.pi / 2) - self.camera_angle_rad - theta_L
        A_Rr = (math.pi / 2) - self.camera_angle_rad + theta_R
        
        if(A_Rr > (math.pi / 2)):
            A_Rr = math.pi - A_Rr
            exceed_Right = True
        return A_Lr,A_Rr,exceed_Right

    #  upper of triangle(three state)
    def Second_quadrant(self,theta_L,theta_R):
        exceed_Right = False
        exceed_Left = False
        A_Lr = (math.pi / 2) - self.camera_angle_rad + theta_L
        A_Rr = (math.pi / 2) - self.camera_angle_rad + theta_R
        
        if(A_Rr > (math.pi / 2)):
            A_Rr = math.pi - A_Rr
            exceed_Right = True

        if(A_Lr > (math.pi / 2)):
            A_Lr = math.pi - A_Lr
            exceed_Left = True
        
        return A_Lr,A_Rr,exceed_Left,exceed_Right
    # Left of triangle(Two state)
    def Third_quadrant(self,theta_L,theta_R):
        exceed_Left = False

        A_Lr = (math.pi / 2) - self.camera_angle_rad + theta_L
        A_Rr = (math.pi / 2) - self.camera_angle_rad - theta_R

        if(A_Lr > (math.pi / 2)):
            A_Lr = math.pi - A_Lr
            exceed_Left = True
        
        return A_Lr,A_Rr,exceed_Left

    # inside of triangle(one state)
    def Fourth_quadrant(self,theta_L,theta_R):
        A_Lr = (math.pi / 2) - self.camera_angle_rad - theta_L
        A_Rr = (math.pi / 2) - self.camera_angle_rad - theta_R
        
        return A_Lr,A_Rr

    def cal_ptr2Right_dis(self,exceed_Left,exceed_Right,k):
        if(exceed_Left or exceed_Right):
            return math.sqrt(pow(camera_config.baseLine,2) / (k - 2 * math.sqrt(k) + 1))
        else:
            return math.sqrt(pow(camera_config.baseLine,2) / (k + 2 * math.sqrt(k) + 1))

    def Cal_w_X(self,exceed_Left,exceed_Right,ptr2Right_dis):
        if(exceed_Left):
            return -(ptr2Right_dis - camera_config.baseLine) 
        elif(exceed_Right):
            return camera_config.baseLine + ptr2Right_dis
        else:
            return camera_config.baseLine - ptr2Right_dis

    def rad2degree(self,rad):
        return (rad / math.pi) * 180