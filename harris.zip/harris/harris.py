# -*- coding: utf-8 -*-

import cv2
import numpy as np
import glob
import matplotlib.pyplot as plt
from world_coord import world_coord   
from mpl_toolkits import mplot3d
from matplotlib import cm 
from mpl_toolkits.mplot3d import Axes3D 


wc = world_coord()
# 找棋盘格角点
# 阈值
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
# print(cv2.TERM_CRITERIA_EPS,'',cv2.TERM_CRITERIA_MAX_ITER)
#w h分别是棋盘格模板长边和短边规格（角点个数）
w = 13
h = 9

# 世界坐标系中的棋盘格点,例如(0,0,0), (1,0,0), (2,0,0) ....,(8,5,0)，去掉Z坐标，记为二维矩阵，认为在棋盘格这个平面上Z=0
objp = np.zeros((w*h,3), np.float32) #构造0矩阵，88行3列，用于存放角点的世界坐标
objp[:,:2] = np.mgrid[0:w,0:h].T.reshape(-1,2)# 三维网格坐标划分

# 储存棋盘格角点的世界坐标和图像坐标对
objpoints = [] # 在世界坐标系中的三维点
imgpoints = [] # 在图像平面的二维点
corn_listR = []
corn_listL = []



imagesL = glob.glob('/home/ivam/socket/testL/*.bmp')
imagesR = glob.glob('/home/ivam/socket/testR/*.bmp')

newlist = []
for fname in imagesL:
    img = cv2.imread(fname)
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    # 粗略找到棋盘格角点 这里找到的是这张图片中角点的亚像素点位置，共11×8 = 88个点，gray必须是8位灰度或者彩色图，（w,h）为角点规模
    ret, corners = cv2.findChessboardCorners(gray, (w,h))
    # 如果找到足够点对，将其存储起来
    if ret == True:
        # print("enter")
        #精确找到角点坐标
        corners = cv2.cornerSubPix(gray,corners,(11,11),(-1,-1),criteria)
        
        for i in range(len(corners)):
            corn_listL.append([corners[i,:,0] , corners[i,:,1]])
        
        # for i in range(len(corners)):
        #     newlist.append(corners[i])
        
        # newlist.sort(key=lambda x:x[1])
        # print(newlist)
        #将正确的objp点放入objpoints中
        objpoints.append(objp)
        imgpoints.append(corners)
        # 将角点在图像上显示
        cv2.drawChessboardCorners(img, (w,h), corners, ret)
        # for i in range(10):
        #     print('Left corners :' , corners[i])
        # print("- - - - - - - - -  - - - - - - - -- - - - -")

        cv2.imshow('findCorners_l',img)
cv2.waitKey(0)




for fname in imagesR:
    img = cv2.imread(fname)
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    # 粗略找到棋盘格角点 这里找到的是这张图片中角点的亚像素点位置，共11×8 = 88个点，gray必须是8位灰度或者彩色图，（w,h）为角点规模
    ret, corners = cv2.findChessboardCorners(gray, (w,h))
    # print("corners : " , corners)
    # 如果找到足够点对，将其存储起来
    if ret == True:
        # print("enter")
        #精确找到角点坐标
        corners = cv2.cornerSubPix(gray,corners,(11,11),(-1,-1),criteria)

        for i in range(len(corners)):
            corn_listR.append([corners[i,:,0] , corners[i,:,1]])
        

        corn_listR.sort(key=lambda s:s[1])
        row1 = []
        row2 = []
        row3 = []
        row4 = []
        row5 = []
        row6 = []
        row7 = []
        row8 = []
        row9 = []   

        for i in range(len(corn_listR)):
            y = corn_listR[i][1]
            
            if(float(y) < 205):
                row1.append(corn_listR[i])
                row1.sort(key = lambda s:s[0])
            elif(y > 220 and y < 240):
                row2.append(corn_listR[i])
                row2.sort(key = lambda s:s[0])
            elif(y > 250 and y < 275):
                row3.append(corn_listR[i])
                row3.sort(key = lambda s:s[0])
            elif(y > 300 and y < 320):
                row4.append(corn_listR[i])
                row4.sort(key = lambda s:s[0])
            elif(y > 330 and y < 350):
                row5.append(corn_listR[i])
                row5.sort(key = lambda s:s[0])
            elif(y > 360 and y < 390):
                row6.append(corn_listR[i])
                row6.sort(key = lambda s:s[0])
            elif(y > 395 and y < 420):
                row7.append(corn_listR[i])
                row7.sort(key = lambda s:s[0])
            elif(y > 425 and y < 455):
                row8.append(corn_listR[i])
                row8.sort(key = lambda s:s[0])
            elif(y > 460):
                row9.append(corn_listR[i])
                row9.sort(key = lambda s:s[0])
            
        row_list = []
        nrow_list = []

        row_list.append(row1)
        row_list.append(row2)
        row_list.append(row3)
        row_list.append(row4)
        row_list.append(row5)
        row_list.append(row6)
        row_list.append(row7)
        row_list.append(row8)
        row_list.append(row9)

        for i in range(len(row_list)):
            for j in range(len(row_list[i])):
                nrow_list.append(row_list[i][j])

        cornR_arr = np.array(nrow_list)
        # for i in range(len(cornR_arr)):
        cv2.drawChessboardCorners(img, (w,h), cornR_arr , ret)

        #将正确的objp点放入objpoints中
        objpoints.append(objp)
        imgpoints.append(corners)
        # 将角点在图像上显示


        # # print(len(cornR_arr))




        cv2.imshow('findCorners_r',img)


cv2.waitKey(0)
cv2.destroyAllWindows()


coord_list = []

for i in range(len(corn_listL)):
    Pot_L = corn_listL[i]
    Pot_R = nrow_list[i]
    x , y , z =  wc.cal_w_XYZ(Pot_L , Pot_R )
    # print('Pot_L',Pot_L)
    # print('Pot_R',Pot_R)
    print('x , y , z',(x , float(y) , z))
    
    coord_list.append([x,float(y),z])
# print(type(corn_listL))
# print(type(nrow_list))

# for i in range(len(coord_list)):
#     print(coord_list[i])
#     print('\n')

ax = plt.axes(projection='3d')
x = []
y = []
z = []

for i in range(len(coord_list)):
    x.append(coord_list[i][0])
    y.append(coord_list[i][1])
    z.append(coord_list[i][2])



fig = plt.figure() 
ax = fig.add_subplot(111, projection='3d') 
ax.set_xlabel(" X Axis ")
ax.set_ylabel(' Y Axis ')
ax.set_zlabel(' Z Axis ')
p3d = ax.scatter(x, y, z, s=30, c=y, cmap = cm.coolwarm) 
plt.show()
